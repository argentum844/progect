from tkinter import *
import tkinter.filedialog
from tkinter import scrolledtext
from Bio import pairwise2
from Bio.pairwise2 import format_alignment


HUMAN=None
NOT_HUMAN=None
gap_penalty = 5
extend_penalty = 0.5
STEPS = []
I = 0

def choose_file(is_human):
    global HUMAN, NOT_HUMAN
    file = tkinter.filedialog.askopenfilename()
    name = file.split('/')[-1]
    if is_human:
        HUMAN = file
        lbl_human.configure(text=name)
    else:
        NOT_HUMAN = file
        lbl_not_human.configure(text=name)


def next_step():
    global I
    I += 1
    if I == len(STEPS):
        I = 0
    txt.configure(text=STEPS[I])


def start_mes():
    global STEPS, I
    STEPS = []
    txt.delete(1.0, END)
    if HUMAN is None or NOT_HUMAN is None:
        txt.insert(INSERT, "Не выбраны файлы")
        return
    try:
        x = ''.join(open(HUMAN).read().split("\n"))
        y = ''.join(open(NOT_HUMAN).read().split("\n"))
    except:
        txt.insert(INSERT, "Ошибка при чтении файлов")
        return
    try:
        if sel.get() == 1:
            alignments = pairwise2.align.globalms(x, y, 1, 0, -gap_penalty, -extend_penalty)
        elif sel.get() == 2:
            alignments = pairwise2.align.localms(x, y, 1, 0, -gap_penalty, -extend_penalty)
        else:
            print(sel)
            txt.insert(INSERT, "Не выбран алгоритм выравнивания")
            return
        score = alignments[0].score
        a = format_alignment(*alignments[0]).split('\n')
        n = len(a[0])

        s =  "*"*60+ '\n' + "Aligned_sequences: 2"+'\n'
        s += "# 1: Human"+'\n'+"# 2: Not human" + '\n'
        s += "# Gap_penalty:" + ' ' + str(gap_penalty) + '\n'
        s += "# Extend_penalty:" + ' ' + str(extend_penalty) + '\n' + "#" + '\n'
        s += "# Длина Human: " + str(len(x)) + '\n'
        s += "# Длина Not Human: " + str(len(y))+'\n'
        s += "# Итоговая длина: " + str(n) + '\n'
        q = a[1].count('|')
        s += "# Идентичность: " + str(q) + '/' + str(n) + ' ' + "(" + str(q / n * 100) + "%)" + '\n'
        s += "# Gaps Human: " + str(n - len(x)) + '\n'
        s += "# Gaps Not Human: " + str(n - len(y)) + '\n'
        s += "# Score: " + str(score) + '\n' + "*"*60
        STEPS.append(s)

        for i in range(n // 50):
            r1 = f"Human {i*50+1}-{i*50+50}:     "
            r2 = f"Not Human {i*50+1}-{i*50+50}: "
            s = r1 + a[0][i*50:i*50+50] + '\n'
            s += ' '*len(r1) + a[1][i*50:i*50+50] + '\n'
            s += r2 + a[2][i*50:i*50+50]
            STEPS.append(s)
        r1 = f"Human {i*50+1}-{n}:     "
        r2 = f"Not Human {i*50+1}-{n}: "
        s = r1 + a[0][i*50+50:n] + '\n'
        s += ' '*len(r1) + a[1][i*50+50:n] + '\n'
        s += r2 + a[2][i*50+50:n]
        STEPS.append(s)

        txt.insert(INSERT, '\n\n\n'.join(STEPS))
    except:
        txt.insert(INSERT, "Что-то пошло не так")


window = Tk()
window.title("Выравнивание последовательностей")
window.geometry('400x400')

btn_human = Button(window, text="Choose human file", command=lambda: choose_file(True))
btn_human.grid(column=0, row=0)
btn_not_human = Button(window, text="Choose not human file", command=lambda: choose_file(False))
btn_not_human.grid(column=1, row=0)

lbl_human = Label(window, text="")
lbl_human.grid(column=0, row=1)
lbl_not_human = Label(window, text="")
lbl_not_human.grid(column=1, row=1)

sel = IntVar()
rad_global = Radiobutton(window, text="Global", value=1, variable=sel)
rad_global.grid(column=0, row=2)
rad_local = Radiobutton(window, text="Local", value=2, variable=sel)
rad_local.grid(column=2, row=2)

btn_start = Button(window, text="START", command=start_mes)
btn_start.grid(column=1, row=3)

# в седующей строчке изменять значение font
txt = scrolledtext.ScrolledText(window,width=85, height=30, bg="white", font="Consolas 10")
txt.grid(columnspan=3, row=4)

#btn_next = Button(window, text="Next", command=next_step)
#btn_next.grid(column=4, row=4)

window.mainloop()

